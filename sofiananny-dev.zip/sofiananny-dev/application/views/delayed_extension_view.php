<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('worker_templates/wheader');
?>

<?php
$this->load->view('worker_templates/wfooter');
?>
