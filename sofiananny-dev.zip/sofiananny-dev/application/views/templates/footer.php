  <div id="footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <h5>Sofiananny</h5>
          <ul class="left-border">
            <li><a href="#">За нас</a></li>
            <li><a href="#">Кариери</a></li>
            <li><a href="#">Често задавани въпроси</a></li>
            <li><a href="#">Условия за ползване</a></li>
          </ul>
        </div>
        <div class="col-sm-4 col-md-3">
          <h5> Административни</h5>
          <ul class="left-border">
            <li><a href="#">Политика за кофиденциалност</a></li>
            <li><a href="#">Политика за поверителност</a></li>
            <li><a href="#">Политика за отмяна</a></li>
            <li><a href="#">Фактури и бележки</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>assets/js/nanny.js" type="text/javascript"></script>
</body>
</html>
