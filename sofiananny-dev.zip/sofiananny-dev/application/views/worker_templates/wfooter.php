  <div id="footer">
    
  </div>
  <script src="<?php echo base_url(); ?>assets/js/workers.js" type="text/javascript"></script>
  <script type="text/javascript">
    $("#items li:nth-child(<?php echo $_SESSION['menu']; ?>)").addClass('active');
  </script>
</body>
</html>
